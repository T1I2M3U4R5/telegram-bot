
# Telegram AI-bot для ЦифроГид

Команды:
/start — запуск бота
/help — меню команд
/ask [вопрос] — ИИ-ответ (ChatGPT)
/generate_image [описание] — генерация изображения (DALL·E)

## Установка

1. pip install -r requirements.txt
2. Создай .env по .env.example и добавь ключи
3. Запусти локально: python bot.py
